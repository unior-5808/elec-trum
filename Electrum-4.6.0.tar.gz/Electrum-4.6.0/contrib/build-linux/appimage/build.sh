#!/bin/bash
#
# env vars:
# - ELECBUILD_NOCACHE: if set, forces rebuild of docker image
# - ELECBUILD_COMMIT: if set, do a fresh clone and git checkout


export PATH="$PATH:/Applications/Docker.app/Contents/Resources/bin/"
set -e

# macOS-compatible PROJECT_ROOT resolution
if command -v realpath >/dev/null 2>&1; then
    PROJECT_ROOT="$(realpath "$(dirname "$0")/../../..")"
else
    PROJECT_ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
fi

PROJECT_ROOT_OR_FRESHCLONE_ROOT="$PROJECT_ROOT"
CONTRIB="$PROJECT_ROOT/contrib"
CONTRIB_APPIMAGE="$CONTRIB/build-linux/appimage"
DISTDIR="$PROJECT_ROOT/dist"

# macOS-compatible UID detection
if [[ "$OSTYPE" == "darwin"* ]]; then
    BUILD_UID=$(id -u)
else
    BUILD_UID=$(/usr/bin/stat -c %u "$PROJECT_ROOT")
fi

. "$CONTRIB"/build_tools_util.sh

DOCKER_BUILD_FLAGS=""
if [ ! -z "$ELECBUILD_NOCACHE" ] ; then
    info "ELECBUILD_NOCACHE is set. Forcing rebuild of Docker image."
    DOCKER_BUILD_FLAGS="--pull --no-cache"
fi

if [ -z "$ELECBUILD_COMMIT" ]; then  # local dev build
    DOCKER_BUILD_FLAGS="$DOCKER_BUILD_FLAGS --build-arg UID=$BUILD_UID"
fi

if [[ "$(docker images -q electrum-appimage-builder-img 2> /dev/null)" == "" || ! -z "$ELECBUILD_NOCACHE" ]]; then
    info "Building Docker image..."
    docker build \
        $DOCKER_BUILD_FLAGS \
        -t electrum-appimage-builder-img \
        "$CONTRIB_APPIMAGE"
else
    info "Docker image exists. Skipping rebuild."
fi

# maybe do fresh clone
if [ ! -z "$ELECBUILD_COMMIT" ]; then
    info "ELECBUILD_COMMIT=$ELECBUILD_COMMIT. Doing fresh clone and git checkout."
    FRESH_CLONE="/tmp/electrum_build/appimage/fresh_clone/electrum"
    rm -rf "$FRESH_CLONE" 2>/dev/null || ( info "We need sudo to rm previous FRESH_CLONE." && sudo rm -rf "$FRESH_CLONE" )
    umask 0022
    git clone "$PROJECT_ROOT" "$FRESH_CLONE"
    cd "$FRESH_CLONE"
    git checkout "$ELECBUILD_COMMIT"
    PROJECT_ROOT_OR_FRESHCLONE_ROOT="$FRESH_CLONE"
else
    info "Not doing fresh clone."
fi

info "Building binary..."
# chown to uid=1000 if doing reproducible build
if [ ! -z "$ELECBUILD_COMMIT" ]; then
    if [ $(id -u) != "1000" ] || [ $(id -g) != "1000" ]; then
        info "Need to chown -R FRESH_CLONE dir. Prompting for sudo."
        sudo chown -R 1000:1000 "$FRESH_CLONE"
    fi
fi

CONTAINER_NAME="electrum-appimage-builder-cont"

docker run -it \
    --name electrum-appimage-builder-cont \
    -v "$PROJECT_ROOT_OR_FRESHCLONE_ROOT":/opt/electrum \
    --rm \
    --workdir /opt/electrum/contrib/build-linux/appimage \
    electrum-appimage-builder-img \
    ./make_appimage.sh


# # Create the container if it doesn't exist
# if [ "$(docker ps -aq -f name=$CONTAINER_NAME)" ]; then
#     if [ "$(docker inspect -f '{{.State.Running}}' $CONTAINER_NAME)" == "true" ]; then
#         info "Stopping running container..."
#         docker stop $CONTAINER_NAME
#     fi
#     info "Starting and attaching to existing container..."
#     docker start -ai $CONTAINER_NAME
# else
#     info "Running new container..."
#     docker create -it \
#         --name $CONTAINER_NAME \
#         -v "$PROJECT_ROOT_OR_FRESHCLONE_ROOT":/opt/electrum \
#         --workdir /opt/electrum/contrib/build-linux/appimage \
#         electrum-appimage-builder-img \
#         ./make_appimage.sh

#     docker start -ai $CONTAINER_NAME
# fi

# Copy results back if needed
if [ ! -z "$ELECBUILD_COMMIT" ]; then
    mkdir -p "$DISTDIR/"
    cp -f "$FRESH_CLONE/dist"/* "$DISTDIR/"
fi