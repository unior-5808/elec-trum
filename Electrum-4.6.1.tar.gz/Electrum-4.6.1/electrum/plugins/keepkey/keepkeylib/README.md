Forked from python-keepkey at  https://github.com/keepkey/python-keepkey/tree/2170fc4479bf5a4b63d2067801ecf041430db769
(which is available on PyPI as keepkey==6.3.1).

A lot of altcoin stuff is removed, and the protobuf-generated code is regenerated with more modern protoc.
